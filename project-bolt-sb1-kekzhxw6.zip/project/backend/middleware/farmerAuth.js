const farmerAuth = (req, res, next) => {
  if (req.user.type !== 'farmer') {
    return res.status(403).json({ 
      message: 'Access denied. Farmer account required.' 
    });
  }
  next();
};

module.exports = farmerAuth;