const express = require('express');
const { body, validationResult } = require('express-validator');
const Review = require('../models/Review');
const Product = require('../models/Product');
const Order = require('../models/Order');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   POST /api/reviews
// @desc    Create a new review
// @access  Private (Buyers only)
router.post('/', [auth], [
  body('product').isMongoId().withMessage('Valid product ID required'),
  body('order').isMongoId().withMessage('Valid order ID required'),
  body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5'),
  body('comment').optional().trim().isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    if (req.user.type !== 'buyer') {
      return res.status(403).json({ message: 'Only buyers can create reviews' });
    }

    const { product, order, rating, comment, images } = req.body;

    // Verify the order exists and belongs to the user
    const orderDoc = await Order.findOne({
      _id: order,
      buyer: req.user.id,
      status: 'delivered'
    });

    if (!orderDoc) {
      return res.status(400).json({ 
        message: 'Order not found or not delivered yet' 
      });
    }

    // Verify the product was in the order
    const orderItem = orderDoc.items.find(item => 
      item.product.toString() === product
    );

    if (!orderItem) {
      return res.status(400).json({ 
        message: 'Product not found in this order' 
      });
    }

    // Check if review already exists
    const existingReview = await Review.findOne({
      product,
      buyer: req.user.id,
      order
    });

    if (existingReview) {
      return res.status(400).json({ 
        message: 'You have already reviewed this product for this order' 
      });
    }

    // Create review
    const review = new Review({
      product,
      buyer: req.user.id,
      order,
      rating,
      comment,
      images: images || [],
      isVerified: true // Since we verified the purchase
    });

    await review.save();
    await review.populate([
      { path: 'buyer', select: 'name' },
      { path: 'product', select: 'name' }
    ]);

    res.status(201).json({
      message: 'Review created successfully',
      review
    });
  } catch (error) {
    console.error('Create review error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/reviews/product/:productId
// @desc    Get reviews for a product
// @access  Public
router.get('/product/:productId', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    const reviews = await Review.find({ product: req.params.productId })
      .populate('buyer', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Review.countDocuments({ product: req.params.productId });

    res.json({
      reviews,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalReviews: total
      }
    });
  } catch (error) {
    console.error('Get product reviews error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/reviews/:id
// @desc    Update a review
// @access  Private (Review owner only)
router.put('/:id', [auth], [
  body('rating').optional().isInt({ min: 1, max: 5 }),
  body('comment').optional().trim().isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }

    // Check if user owns the review
    if (review.buyer.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to update this review' });
    }

    // Update review
    if (req.body.rating) review.rating = req.body.rating;
    if (req.body.comment !== undefined) review.comment = req.body.comment;
    if (req.body.images) review.images = req.body.images;

    await review.save();
    await review.populate('buyer', 'name');

    res.json({
      message: 'Review updated successfully',
      review
    });
  } catch (error) {
    console.error('Update review error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/reviews/:id
// @desc    Delete a review
// @access  Private (Review owner only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }

    // Check if user owns the review
    if (review.buyer.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to delete this review' });
    }

    await review.remove();

    res.json({ message: 'Review deleted successfully' });
  } catch (error) {
    console.error('Delete review error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;