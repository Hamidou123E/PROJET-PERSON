const express = require('express');
const { body, validationResult } = require('express-validator');
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   POST /api/orders
// @desc    Create a new order
// @access  Private (Buyers only)
router.post('/', [auth], [
  body('items').isArray({ min: 1 }).withMessage('Order must contain at least one item'),
  body('items.*.product').isMongoId().withMessage('Valid product ID required'),
  body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('shippingAddress.street').trim().isLength({ min: 5 }),
  body('shippingAddress.city').trim().isLength({ min: 2 }),
  body('shippingAddress.postalCode').trim().isLength({ min: 5 }),
  body('paymentMethod').isIn(['card', 'paypal', 'bank_transfer'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    if (req.user.type !== 'buyer') {
      return res.status(403).json({ message: 'Only buyers can create orders' });
    }

    const { items, shippingAddress, billingAddress, paymentMethod, notes } = req.body;

    // Validate products and calculate total
    let totalAmount = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await Product.findById(item.product).populate('farmer');
      
      if (!product || !product.isActive) {
        return res.status(400).json({ 
          message: `Product ${item.product} not found or inactive` 
        });
      }

      if (product.quantity < item.quantity) {
        return res.status(400).json({ 
          message: `Insufficient quantity for product ${product.name}` 
        });
      }

      const itemTotal = product.price * item.quantity;
      totalAmount += itemTotal;

      orderItems.push({
        product: product._id,
        quantity: item.quantity,
        price: product.price,
        farmer: product.farmer._id
      });

      // Update product quantity
      product.quantity -= item.quantity;
      await product.save();
    }

    // Create order
    const order = new Order({
      buyer: req.user.id,
      items: orderItems,
      totalAmount,
      shippingAddress,
      billingAddress: billingAddress || shippingAddress,
      paymentMethod,
      notes
    });

    await order.save();
    await order.populate([
      { path: 'buyer', select: 'name email' },
      { path: 'items.product', select: 'name images' },
      { path: 'items.farmer', select: 'name' }
    ]);

    res.status(201).json({
      message: 'Order created successfully',
      order
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/orders
// @desc    Get user orders
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const filter = {};
    
    if (req.user.type === 'buyer') {
      filter.buyer = req.user.id;
    } else if (req.user.type === 'farmer') {
      filter['items.farmer'] = req.user.id;
    }

    const orders = await Order.find(filter)
      .populate('buyer', 'name email')
      .populate('items.product', 'name images')
      .populate('items.farmer', 'name')
      .sort({ createdAt: -1 });

    res.json({ orders });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/orders/:id
// @desc    Get single order
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('buyer', 'name email phone')
      .populate('items.product', 'name images description')
      .populate('items.farmer', 'name location phone');

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check authorization
    const isAuthorized = order.buyer._id.toString() === req.user.id ||
                        order.items.some(item => item.farmer._id.toString() === req.user.id);

    if (!isAuthorized) {
      return res.status(403).json({ message: 'Not authorized to view this order' });
    }

    res.json({ order });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/orders/:id/status
// @desc    Update order status
// @access  Private (Farmers only)
router.put('/:id/status', [auth], [
  body('status').isIn(['confirmed', 'preparing', 'shipped', 'delivered', 'cancelled'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    if (req.user.type !== 'farmer') {
      return res.status(403).json({ message: 'Only farmers can update order status' });
    }

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if farmer is involved in this order
    const isInvolved = order.items.some(item => 
      item.farmer.toString() === req.user.id
    );

    if (!isInvolved) {
      return res.status(403).json({ message: 'Not authorized to update this order' });
    }

    order.status = req.body.status;
    if (req.body.trackingNumber) {
      order.trackingNumber = req.body.trackingNumber;
    }

    await order.save();

    res.json({
      message: 'Order status updated successfully',
      order
    });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;