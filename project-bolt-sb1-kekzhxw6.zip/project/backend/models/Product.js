const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
    maxlength: [100, 'Product name cannot exceed 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
    trim: true,
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: ['Légumes', 'Fruits', 'Céréales', 'Légumineuses', 'Herbes aromatiques', 'Produits laitiers', 'Œufs', 'Miel']
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price cannot be negative']
  },
  unit: {
    type: String,
    required: [true, 'Unit is required'],
    enum: ['kg', 'g', 'pièce', 'botte', 'litre', 'pot']
  },
  quantity: {
    type: Number,
    required: [true, 'Quantity is required'],
    min: [0, 'Quantity cannot be negative']
  },
  images: [{
    type: String,
    required: true
  }],
  farmer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  location: {
    type: String,
    required: [true, 'Location is required'],
    trim: true
  },
  organic: {
    type: Boolean,
    default: false
  },
  harvestDate: {
    type: Date,
    required: [true, 'Harvest date is required']
  },
  expiryDate: {
    type: Date
  },
  isActive: {
    type: Boolean,
    default: true
  },
  // Calculated fields
  rating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  reviewCount: {
    type: Number,
    default: 0
  },
  // SEO and search
  tags: [String],
  searchKeywords: [String]
}, {
  timestamps: true
});

// Indexes for better query performance
productSchema.index({ farmer: 1 });
productSchema.index({ category: 1 });
productSchema.index({ location: 1 });
productSchema.index({ organic: 1 });
productSchema.index({ isActive: 1 });
productSchema.index({ name: 'text', description: 'text' });

// Virtual for farmer details
productSchema.virtual('farmerDetails', {
  ref: 'User',
  localField: 'farmer',
  foreignField: '_id',
  justOne: true
});

// Update rating when reviews change
productSchema.methods.updateRating = async function() {
  const Review = mongoose.model('Review');
  const stats = await Review.aggregate([
    { $match: { product: this._id } },
    {
      $group: {
        _id: null,
        averageRating: { $avg: '$rating' },
        totalReviews: { $sum: 1 }
      }
    }
  ]);

  if (stats.length > 0) {
    this.rating = Math.round(stats[0].averageRating * 10) / 10;
    this.reviewCount = stats[0].totalReviews;
  } else {
    this.rating = 0;
    this.reviewCount = 0;
  }

  await this.save();
};

module.exports = mongoose.model('Product', productSchema);