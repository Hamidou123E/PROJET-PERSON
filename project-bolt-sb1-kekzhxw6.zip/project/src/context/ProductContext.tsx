import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, Review } from '../types';

interface ProductContextType {
  products: Product[];
  reviews: Review[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewCount'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;
  getProductsByFarmer: (farmerId: string) => Product[];
  searchProducts: (query: string, category?: string, location?: string) => Product[];
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};

interface ProductProviderProps {
  children: ReactNode;
}

// Sample data
const sampleProducts: Product[] = [
  {
    id: '1',
    farmerId: 'farmer1',
    farmerName: 'Marie Dupont',
    name: 'Tomates Bio',
    description: 'Tomates biologiques cultivées sans pesticides dans notre ferme familiale.',
    category: 'Légumes',
    price: 4.50,
    unit: 'kg',
    quantity: 100,
    images: ['https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg'],
    location: 'Provence, France',
    organic: true,
    harvestDate: '2025-01-15',
    rating: 4.5,
    reviewCount: 12,
    createdAt: '2025-01-10T10:00:00Z'
  },
  {
    id: '2',
    farmerId: 'farmer2',
    farmerName: 'Jean Martin',
    name: 'Pommes Golden',
    description: 'Pommes Golden fraîches, croquantes et sucrées de nos vergers.',
    category: 'Fruits',
    price: 3.20,
    unit: 'kg',
    quantity: 200,
    images: ['https://images.pexels.com/photos/1068584/pexels-photo-1068584.jpeg'],
    location: 'Normandie, France',
    organic: false,
    harvestDate: '2025-01-12',
    rating: 4.8,
    reviewCount: 25,
    createdAt: '2025-01-08T14:30:00Z'
  },
  {
    id: '3',
    farmerId: 'farmer1',
    farmerName: 'Marie Dupont',
    name: 'Courgettes',
    description: 'Courgettes fraîches et tendres, parfaites pour vos plats d\'été.',
    category: 'Légumes',
    price: 2.80,
    unit: 'kg',
    quantity: 75,
    images: ['https://images.pexels.com/photos/128420/pexels-photo-128420.jpeg'],
    location: 'Provence, France',
    organic: true,
    harvestDate: '2025-01-14',
    rating: 4.2,
    reviewCount: 8,
    createdAt: '2025-01-09T09:15:00Z'
  }
];

export const ProductProvider: React.FC<ProductProviderProps> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    const storedProducts = localStorage.getItem('agrimarket_products');
    const storedReviews = localStorage.getItem('agrimarket_reviews');
    
    if (storedProducts) {
      setProducts(JSON.parse(storedProducts));
    } else {
      setProducts(sampleProducts);
      localStorage.setItem('agrimarket_products', JSON.stringify(sampleProducts));
    }
    
    if (storedReviews) {
      setReviews(JSON.parse(storedReviews));
    }
  }, []);

  const addProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewCount'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      rating: 0,
      reviewCount: 0
    };

    const updatedProducts = [...products, newProduct];
    setProducts(updatedProducts);
    localStorage.setItem('agrimarket_products', JSON.stringify(updatedProducts));
  };

  const updateProduct = (id: string, productData: Partial<Product>) => {
    const updatedProducts = products.map(product =>
      product.id === id ? { ...product, ...productData } : product
    );
    setProducts(updatedProducts);
    localStorage.setItem('agrimarket_products', JSON.stringify(updatedProducts));
  };

  const deleteProduct = (id: string) => {
    const updatedProducts = products.filter(product => product.id !== id);
    setProducts(updatedProducts);
    localStorage.setItem('agrimarket_products', JSON.stringify(updatedProducts));
  };

  const addReview = (reviewData: Omit<Review, 'id' | 'createdAt'>) => {
    const newReview: Review = {
      ...reviewData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };

    const updatedReviews = [...reviews, newReview];
    setReviews(updatedReviews);
    localStorage.setItem('agrimarket_reviews', JSON.stringify(updatedReviews));

    // Update product rating
    const productReviews = updatedReviews.filter(r => r.productId === reviewData.productId);
    const averageRating = productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length;
    
    updateProduct(reviewData.productId, {
      rating: Math.round(averageRating * 10) / 10,
      reviewCount: productReviews.length
    });
  };

  const getProductsByFarmer = (farmerId: string) => {
    return products.filter(product => product.farmerId === farmerId);
  };

  const searchProducts = (query: string, category?: string, location?: string) => {
    return products.filter(product => {
      const matchesQuery = !query || 
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        product.description.toLowerCase().includes(query.toLowerCase());
      const matchesCategory = !category || product.category === category;
      const matchesLocation = !location || product.location.toLowerCase().includes(location.toLowerCase());
      
      return matchesQuery && matchesCategory && matchesLocation;
    });
  };

  return (
    <ProductContext.Provider value={{
      products,
      reviews,
      addProduct,
      updateProduct,
      deleteProduct,
      addReview,
      getProductsByFarmer,
      searchProducts
    }}>
      {children}
    </ProductContext.Provider>
  );
};