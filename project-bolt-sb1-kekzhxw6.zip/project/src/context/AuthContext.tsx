import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Omit<User, 'id' | 'createdAt'> & { password: string }) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('agrimarket_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('agrimarket_users') || '[]');
    const foundUser = users.find((u: User & { password: string }) => 
      u.email === email && u.password === password
    );

    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('agrimarket_user', JSON.stringify(userWithoutPassword));
      return true;
    }
    return false;
  };

  const register = async (userData: Omit<User, 'id' | 'createdAt'> & { password: string }): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('agrimarket_users') || '[]');
    
    // Initialize with demo users if storage is empty
    if (users.length === 0) {
      const demoUsers = [
        {
          id: 'farmer1',
          email: 'farmer@demo.com',
          password: 'password123',
          name: 'Marie Dupont',
          type: 'farmer',
          location: 'Provence, France',
          phone: '06 12 34 56 78',
          description: 'Exploitation familiale bio depuis 3 générations',
          createdAt: '2025-01-01T00:00:00Z'
        },
        {
          id: 'buyer1',
          email: 'buyer@demo.com',
          password: 'password123',
          name: 'Jean Martin',
          type: 'buyer',
          location: 'Lyon, France',
          phone: '06 98 76 54 32',
          description: 'Passionné de produits locaux et bio',
          createdAt: '2025-01-01T00:00:00Z'
        }
      ];
      localStorage.setItem('agrimarket_users', JSON.stringify(demoUsers));
      users.push(...demoUsers);
    }
    
    if (users.find((u: User) => u.email === userData.email)) {
      return false; // User already exists
    }

    const newUser: User & { password: string } = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    localStorage.setItem('agrimarket_users', JSON.stringify(users));

    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    localStorage.setItem('agrimarket_user', JSON.stringify(userWithoutPassword));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('agrimarket_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};