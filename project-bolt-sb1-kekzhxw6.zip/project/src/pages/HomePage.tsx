import React from 'react';
import { Link } from 'react-router-dom';
import { Truck, Shield, Heart, Award, Users, Leaf } from 'lucide-react';
import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import { useProducts } from '../context/ProductContext';

const HomePage: React.FC = () => {
  const { products } = useProducts();
  const featuredProducts = products.slice(0, 6);

  const features = [
    {
      icon: Truck,
      title: 'Livraison Rapide',
      description: 'Livraison directe depuis la ferme vers votre porte en 24-48h'
    },
    {
      icon: Shield,
      title: 'Qualité Garantie',
      description: 'Tous nos produits sont contrôlés et certifiés par nos agriculteurs partenaires'
    },
    {
      icon: Heart,
      title: 'Soutien Local',
      description: 'Soutenez directement les agriculteurs locaux et contribuez à l\'économie régionale'
    },
    {
      icon: Award,
      title: 'Meilleurs Prix',
      description: 'Des prix justes pour tous grâce à l\'élimination des intermédiaires'
    }
  ];

  const benefits = [
    {
      icon: Users,
      title: 'Pour les Acheteurs',
      description: 'Accédez à des produits frais, locaux et de qualité directement depuis la source.',
      points: ['Produits ultra-frais', 'Prix transparents', 'Traçabilité complète', 'Livraison rapide']
    },
    {
      icon: Leaf,
      title: 'Pour les Agriculteurs',
      description: 'Vendez directement vos produits et maximisez vos revenus sans intermédiaires.',
      points: ['Meilleure marge', 'Relation directe', 'Gestion simplifiée', 'Paiements sécurisés']
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero />

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Pourquoi choisir AgriMarket ?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Une plateforme innovante qui révolutionne la façon dont les produits agricoles 
              sont achetés et vendus en France.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 group-hover:bg-green-200 transition-colors">
                  <feature.icon className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Produits en Vedette
            </h2>
            <p className="text-xl text-gray-600">
              Découvrez une sélection de nos meilleurs produits frais
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center">
            <Link
              to="/products"
              className="inline-flex items-center px-8 py-4 bg-green-600 text-white font-semibold rounded-xl hover:bg-green-700 transition-colors"
            >
              Voir tous les produits
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Des avantages pour tous
            </h2>
            <p className="text-xl text-gray-600">
              AgriMarket profite à toute la chaîne alimentaire
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-green-100 rounded-full w-12 h-12 flex items-center justify-center mr-4">
                    <benefit.icon className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">{benefit.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6">{benefit.description}</p>
                
                <ul className="space-y-3">
                  {benefit.points.map((point, pointIndex) => (
                    <li key={pointIndex} className="flex items-center text-gray-700">
                      <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Prêt à rejoindre AgriMarket ?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers d'agriculteurs et d'acheteurs qui font déjà confiance à notre plateforme.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="inline-flex items-center px-8 py-4 bg-white text-green-600 font-semibold rounded-xl hover:bg-gray-100 transition-colors"
            >
              Créer mon compte
            </Link>
            <Link
              to="/products"
              className="inline-flex items-center px-8 py-4 bg-green-700 text-white font-semibold rounded-xl hover:bg-green-800 transition-colors"
            >
              Explorer maintenant
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;