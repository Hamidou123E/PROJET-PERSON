import React from 'react';
import { Users, Target, Award, Heart, Leaf, TrendingUp } from 'lucide-react';

const AboutPage: React.FC = () => {
  const values = [
    {
      icon: Heart,
      title: 'Passion pour l\'agriculture',
      description: 'Nous croyons en l\'importance de soutenir nos agriculteurs locaux et de promouvoir une agriculture durable.'
    },
    {
      icon: Users,
      title: 'Communauté',
      description: 'Nous créons des liens directs entre producteurs et consommateurs pour une économie plus équitable.'
    },
    {
      icon: Leaf,
      title: 'Durabilité',
      description: 'Nous encourageons les pratiques agricoles respectueuses de l\'environnement et la consommation responsable.'
    },
    {
      icon: Award,
      title: 'Qualité',
      description: 'Nous garantissons la fraîcheur et la qualité de tous les produits vendus sur notre plateforme.'
    }
  ];

  const stats = [
    { number: '500+', label: 'Agriculteurs partenaires' },
    { number: '10,000+', label: 'Produits disponibles' },
    { number: '50,000+', label: 'Clients satisfaits' },
    { number: '95%', label: 'Taux de satisfaction' }
  ];

  const team = [
    {
      name: 'Marie Dubois',
      role: 'Fondatrice & CEO',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300',
      description: 'Ancienne ingénieure agronome, Marie a créé AgriMarket pour soutenir les agriculteurs français.'
    },
    {
      name: 'Pierre Martin',
      role: 'Directeur Technique',
      image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=300',
      description: 'Expert en technologie, Pierre développe les outils qui facilitent la vente directe.'
    },
    {
      name: 'Sophie Laurent',
      role: 'Responsable Partenariats',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300',
      description: 'Sophie travaille directement avec les agriculteurs pour les accompagner sur la plateforme.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              À propos d'AgriMarket
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
              Nous révolutionnons la vente de produits agricoles en connectant directement 
              les agriculteurs aux consommateurs, créant une économie plus juste et durable.
            </p>
            <div className="grid md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-4xl font-bold text-green-600 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Notre Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                AgriMarket a été créé avec une vision simple mais puissante : éliminer les 
                intermédiaires entre les agriculteurs et les consommateurs pour créer un 
                système alimentaire plus équitable et durable.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Nous croyons que les agriculteurs méritent une rémunération juste pour leur 
                travail, et que les consommateurs ont le droit d'accéder à des produits frais, 
                locaux et de qualité à des prix transparents.
              </p>
              <div className="flex items-center space-x-4">
                <Target className="h-8 w-8 text-green-600" />
                <span className="text-lg font-semibold text-gray-900">
                  Connecter. Soutenir. Prospérer.
                </span>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Agriculteur dans son champ"
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center space-x-3">
                  <TrendingUp className="h-8 w-8 text-green-600" />
                  <div>
                    <div className="font-bold text-gray-900">+40%</div>
                    <div className="text-sm text-gray-600">Revenus agriculteurs</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nos Valeurs</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Les principes qui guident notre action quotidienne pour transformer 
              le secteur agricole français.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                  <value.icon className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  {value.title}
                </h3>
                <p className="text-gray-600 text-center">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Notre Équipe</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Une équipe passionnée et expérimentée, dédiée à la transformation 
              du secteur agricole français.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="text-center">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
                />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-green-600 font-medium mb-4">{member.role}</p>
                <p className="text-gray-600">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-20 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Notre Impact
          </h2>
          <p className="text-xl text-green-100 mb-12 max-w-3xl mx-auto">
            Depuis notre création, nous avons aidé des centaines d'agriculteurs à 
            améliorer leurs revenus et des milliers de familles à accéder à des 
            produits frais et locaux.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 text-white">
            <div>
              <div className="text-4xl font-bold mb-2">2.5M€</div>
              <div className="text-green-100">Revenus générés pour les agriculteurs</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">150</div>
              <div className="text-green-100">Communes desservies</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">80%</div>
              <div className="text-green-100">Produits biologiques ou locaux</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;